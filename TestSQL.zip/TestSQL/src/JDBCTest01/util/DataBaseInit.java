package JDBCTest01.util;

public class DataBaseInit {
}
